"""
X-Fashion v2: Explainable AI Personal Stylist
Enhanced UI — Pinterest-inspired cards, SVG illustrations,
image upload, Buy The Look, outfit vibe, hairstyle suggestions.

ENGINE UNCHANGED — only UI/UX and features added.
"""

import streamlit as st
import os, sys, base64

sys.path.insert(0, os.path.dirname(__file__))

from recommendation_engine import XFashionEngine, UserProfile, Outfit, ClothingItem
from utils import get_color_hex, get_item_emoji, format_item_name, score_to_stars, score_to_grade
from image_utils import (
    generate_outfit_svg, get_shop_links, get_outfit_vibe,
    get_hairstyle_suggestions, detect_category_from_filename,
    detect_dominant_color_from_name,
)

# ── Page config ────────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="X-Fashion · AI Stylist",
    page_icon="✦",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Fonts + Global CSS ─────────────────────────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;1,300;1,400&family=Outfit:wght@300;400;500;600&display=swap');

:root {
  --bg:         #F7F4F0;
  --surface:    #FFFFFF;
  --card:       #FFFFFF;
  --sidebar:    #1A1814;
  --border:     #E8E2D9;
  --border2:    #D4CCC0;
  --accent:     #B5936B;
  --accent2:    #8B6F47;
  --accent-soft:#F0E8DC;
  --ink:        #1C1916;
  --muted:      #8A8078;
  --muted2:     #B8B0A6;
  --success:    #5B8A6F;
  --danger:     #C0574A;
  --tag-bg:     #F0EBE4;
  --radius:     14px;
  --radius-sm:  8px;
  --shadow:     0 2px 20px rgba(28,25,22,0.08);
  --shadow-lg:  0 8px 40px rgba(28,25,22,0.13);
  --transition: 0.25s cubic-bezier(0.4,0,0.2,1);
}

html, body, [class*="css"] {
  font-family: 'Outfit', sans-serif !important;
  background: var(--bg) !important;
  color: var(--ink) !important;
}
h1,h2,h3,h4 { font-family: 'Cormorant Garamond', serif !important; }

::-webkit-scrollbar { width: 5px; }
::-webkit-scrollbar-thumb { background: var(--border2); border-radius: 10px; }

/* ── Sidebar ── */
section[data-testid="stSidebar"] {
  background: var(--sidebar) !important;
  border-right: none !important;
  box-shadow: 4px 0 30px rgba(0,0,0,0.15);
}
section[data-testid="stSidebar"] * { color: #D4CCB8 !important; }
section[data-testid="stSidebar"] .stSelectbox > div > div {
  background: #28241F !important;
  border: 1px solid #3A352C !important;
  border-radius: var(--radius-sm) !important;
  color: #E8E0D0 !important;
}
section[data-testid="stSidebar"] .stSelectbox label,
section[data-testid="stSidebar"] .stSlider label,
section[data-testid="stSidebar"] .stFileUploader label {
  color: #6A6058 !important;
  font-size: 0.68rem !important;
  letter-spacing: 0.1em !important;
  text-transform: uppercase;
}
section[data-testid="stSidebar"] hr { border-color: #2E2A24 !important; margin: 0.8rem 0 !important; }

/* ── Generate Button ── */
.stButton > button {
  background: linear-gradient(135deg, #B5936B 0%, #8B6F47 100%) !important;
  color: #FFFFFF !important;
  font-family: 'Outfit', sans-serif !important;
  font-weight: 600 !important;
  font-size: 0.85rem !important;
  letter-spacing: 0.08em !important;
  text-transform: uppercase;
  border: none !important;
  border-radius: 10px !important;
  padding: 0.7rem 1.5rem !important;
  width: 100% !important;
  transition: all var(--transition) !important;
  box-shadow: 0 4px 15px rgba(139,111,71,0.4) !important;
}
.stButton > button:hover {
  transform: translateY(-2px) !important;
  box-shadow: 0 8px 25px rgba(139,111,71,0.5) !important;
}

.block-container { padding: 0 2rem 3rem !important; max-width: 1400px; }

/* ── Hero header ── */
.xf-hero { padding: 3rem 0 2rem; border-bottom: 1px solid var(--border); margin-bottom: 2.5rem; }
.xf-wordmark {
  font-size: 0.68rem; font-weight: 600; letter-spacing: 0.25em; text-transform: uppercase;
  color: var(--accent); background: var(--accent-soft); padding: 0.3rem 0.8rem;
  border-radius: 20px; display: inline-block; margin-bottom: 0.7rem;
}
.xf-hero h1 {
  font-size: 2.8rem !important; font-weight: 300; letter-spacing: -0.02em;
  color: var(--ink); margin: 0; line-height: 1.1;
}
.xf-hero h1 em { font-style: italic; color: var(--accent); }
.xf-hero p { color: var(--muted); font-size: 0.88rem; margin: 0.5rem 0 0; }

/* ── Profile tags ── */
.profile-strip { display: flex; flex-wrap: wrap; gap: 0.4rem; margin-bottom: 2rem; align-items: center; }
.profile-strip .plabel { font-size: 0.68rem; text-transform: uppercase; letter-spacing: 0.1em; color: var(--muted); margin-right: 0.3rem; }
.ptag {
  display: inline-flex; align-items: center; gap: 0.3rem;
  background: var(--tag-bg); border: 1px solid var(--border2);
  color: var(--ink); border-radius: 20px; padding: 0.22rem 0.65rem;
  font-size: 0.73rem; font-weight: 500;
}

/* ── Outfit card ── */
@keyframes fadeUp {
  from { opacity:0; transform:translateY(18px); }
  to   { opacity:1; transform:translateY(0); }
}
.outfit-card {
  background: var(--card); border: 1px solid var(--border); border-radius: 20px;
  overflow: hidden; box-shadow: var(--shadow);
  transition: box-shadow var(--transition), transform var(--transition), border-color var(--transition);
  animation: fadeUp 0.4s ease both;
  margin-bottom: 1.5rem;
}
.outfit-card:hover { box-shadow: var(--shadow-lg); transform: translateY(-4px); border-color: var(--accent); }
.outfit-card:nth-child(1){animation-delay:0.05s}
.outfit-card:nth-child(2){animation-delay:0.12s}
.outfit-card:nth-child(3){animation-delay:0.19s}
.outfit-card:nth-child(4){animation-delay:0.26s}
.outfit-card:nth-child(5){animation-delay:0.33s}
.outfit-card:nth-child(6){animation-delay:0.4s}

/* Illustration panel */
.card-illus {
  position: relative; background: linear-gradient(145deg, #F2EDE6 0%, #E8E0D4 100%);
  height: 270px; display: flex; align-items: center; justify-content: center; overflow: hidden;
}
.card-illus img { height: 255px; filter: drop-shadow(0 4px 14px rgba(0,0,0,0.1)); }
.grade-pill {
  position: absolute; top: 12px; right: 12px; width: 40px; height: 40px;
  border-radius: 50%; display: flex; align-items: center; justify-content: center;
  font-family: 'Cormorant Garamond', serif; font-size: 1.1rem; font-weight: 600;
  color: white; box-shadow: 0 3px 12px rgba(0,0,0,0.2);
}
.vibe-tag {
  position: absolute; bottom: 12px; left: 50%; transform: translateX(-50%);
  background: rgba(255,255,255,0.93); backdrop-filter: blur(10px);
  border-radius: 20px; padding: 0.3rem 0.9rem; font-size: 0.73rem; font-weight: 500;
  color: var(--ink); white-space: nowrap; box-shadow: 0 2px 10px rgba(0,0,0,0.1);
}
.rank-tag {
  position: absolute; top: 12px; left: 12px;
  background: var(--accent); color: white; border-radius: 20px;
  padding: 0.22rem 0.65rem; font-size: 0.68rem; font-weight: 600; letter-spacing: 0.08em; text-transform: uppercase;
}

/* Card body */
.card-body { padding: 1.3rem 1.4rem; }
.card-title { font-family: 'Cormorant Garamond', serif; font-size: 1.22rem; font-weight: 400; color: var(--ink); margin: 0 0 0.15rem; }
.card-sub { font-size: 0.7rem; color: var(--muted); text-transform: uppercase; letter-spacing: 0.08em; margin-bottom: 0.9rem; }
.score-track { height: 3px; background: var(--border); border-radius: 3px; margin-bottom: 1.1rem; overflow: hidden; }
.score-fill { height: 100%; border-radius: 3px; background: linear-gradient(90deg, var(--accent), var(--accent2)); }

/* Item rows */
.items-sec { margin-bottom: 1rem; }
.item-row {
  display: flex; align-items: center; gap: 0.6rem;
  padding: 0.45rem 0; border-bottom: 1px solid var(--border);
}
.item-row:last-child { border-bottom: none; }
.item-slot { font-size: 0.62rem; font-weight: 600; letter-spacing: 0.1em; text-transform: uppercase; color: var(--muted2); width: 78px; flex-shrink: 0; }
.item-emoji { font-size: 1rem; }
.item-name { font-size: 0.82rem; font-weight: 500; color: var(--ink); flex: 1; }
.item-fit { color: var(--muted2); font-weight: 400; font-size: 0.7rem; }
.cswatch { width: 12px; height: 12px; border-radius: 3px; border: 1.5px solid rgba(0,0,0,0.08); flex-shrink: 0; }
.cname { font-size: 0.7rem; color: var(--muted); }

/* XAI */
.xai-box {
  background: linear-gradient(135deg,#FBF7F2,#F5EFE6); border: 1px solid #E8DDD0;
  border-radius: 10px; padding: 0.9rem 1rem; margin-bottom: 1rem;
}
.xai-lbl { font-size: 0.62rem; font-weight: 600; letter-spacing: 0.12em; text-transform: uppercase; color: var(--accent2); margin-bottom: 0.45rem; }
.xai-pt {
  display: flex; align-items: flex-start; gap: 0.45rem;
  font-size: 0.78rem; color: #5C5650; margin-bottom: 0.25rem; line-height: 1.4;
}
.xai-pt::before { content: "✓"; color: var(--success); font-weight: 700; flex-shrink: 0; }

/* Hair */
.hair-row { display: flex; align-items: center; gap: 0.45rem; flex-wrap: wrap; margin-bottom: 0.9rem; }
.hair-lbl { font-size: 0.62rem; text-transform: uppercase; letter-spacing: 0.1em; color: var(--muted); }
.hair-chip { background: #EDF2FF; color: #3D5BB5; border-radius: 12px; padding: 0.2rem 0.6rem; font-size: 0.72rem; font-weight: 500; }

/* Shop */
.shop-lbl { font-size: 0.62rem; text-transform: uppercase; letter-spacing: 0.1em; color: var(--muted); margin-bottom: 0.45rem; }
.shop-row { display: flex; gap: 0.4rem; flex-wrap: wrap; }
.shop-btn {
  display: inline-flex; align-items: center; gap: 0.3rem;
  padding: 0.3rem 0.65rem; border-radius: 7px; font-size: 0.72rem; font-weight: 500;
  text-decoration: none !important; border: 1.5px solid var(--btn-color,#999);
  color: var(--btn-color,#999) !important; background: white;
  transition: all 0.2s ease;
}
.shop-btn:hover {
  background: var(--btn-color,#999) !important; color: white !important;
  transform: translateY(-1px); box-shadow: 0 3px 10px rgba(0,0,0,0.12);
}

/* Empty hero */
.empty-wrap { text-align: center; padding: 4.5rem 2rem 2rem; }
.empty-wrap .e-icon { font-size: 3.5rem; opacity:0.3; margin-bottom: 1.2rem; }
.empty-wrap h2 { font-size: 2.2rem; font-weight: 300; color: var(--ink); margin-bottom: 0.5rem; }
.empty-wrap p { color: var(--muted); font-size: 0.88rem; max-width: 400px; margin: 0 auto; line-height: 1.6; }

/* Feature cards */
.feat-grid { display: grid; grid-template-columns: repeat(3,1fr); gap: 1.1rem; margin-top: 2.5rem; }
.feat-card {
  background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius);
  padding: 1.3rem; text-align: center;
  transition: box-shadow var(--transition), transform var(--transition);
}
.feat-card:hover { box-shadow: var(--shadow-lg); transform: translateY(-3px); }
.feat-icon { font-size: 1.7rem; margin-bottom: 0.5rem; }
.feat-title { font-family: 'Cormorant Garamond', serif; font-size: 1rem; color: var(--accent2); margin-bottom: 0.35rem; }
.feat-desc { font-size: 0.78rem; color: var(--muted); line-height: 1.5; }

/* Sidebar logo */
.sb-logo { padding: 1.5rem 1rem 0.3rem; font-family: 'Cormorant Garamond', serif; font-size: 1.45rem; color: #E8DFC8 !important; letter-spacing: 0.04em; }
.sb-logo span { color: #B5936B !important; }
.sb-tag { font-size: 0.62rem; color: #5C5448 !important; letter-spacing: 0.14em; text-transform: uppercase; padding: 0 1rem 0.8rem; display: block; }

/* detected badge */
.det-badge {
  display:inline-flex; align-items:center; gap:0.35rem; background:#EEF7EE;
  border:1px solid #B8DDB8; color:#3A6B3A; border-radius:20px;
  padding:0.28rem 0.75rem; font-size:0.75rem; font-weight:500; margin-top:0.4rem;
}

/* Tabs */
.stTabs [data-baseweb="tab-list"] { background: transparent !important; border-bottom: 1px solid var(--border) !important; }
.stTabs [data-baseweb="tab"] { background:transparent !important; color:var(--muted) !important; font-size:0.78rem !important; letter-spacing:0.06em; text-transform:uppercase; }
.stTabs [data-baseweb="tab"][aria-selected="true"] { color:var(--ink) !important; border-bottom:2px solid var(--accent) !important; }

hr { border-color: var(--border) !important; }
[data-testid="stMetric"] { background:var(--surface); border:1px solid var(--border); border-radius:var(--radius); padding:0.9rem; }
[data-testid="stMetricValue"] { font-family:'Cormorant Garamond',serif !important; font-size:1.9rem !important; color:var(--accent) !important; }
[data-testid="stMetricLabel"] { font-size:0.7rem !important; color:var(--muted) !important; text-transform:uppercase; letter-spacing:0.06em; }
</style>
""", unsafe_allow_html=True)

# ── Session state ──────────────────────────────────────────────────────────────
for k, v in [("outfits",[]),("profile",None),("upload_category",None),("upload_color",None)]:
    if k not in st.session_state:
        st.session_state[k] = v


@st.cache_resource(show_spinner=False)
def load_engine():
    return XFashionEngine(dataset_path="data/fashion_dataset.csv")


# ── Sidebar ────────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown('<div class="sb-logo">✦ X<span>Fashion</span></div><span class="sb-tag">AI Personal Stylist v2</span>', unsafe_allow_html=True)
    st.markdown("---")

    weather     = st.selectbox("Season / Weather",   ["summer","winter","spring","autumn"])
    occasion    = st.selectbox("Occasion",           ["daily","office","party","date","travel","gym","formal_event","wedding","festival","casual"])
    outfit_type = st.selectbox("Outfit Style",       ["western","ethnic","indo_western","college","formal","party"])
    st.markdown("---")
    body_type   = st.selectbox("Body Type",          ["pear","apple","hourglass","rectangle","petite","tall","plus"])
    skin_tone   = st.selectbox("Skin Tone",          ["warm","cool","neutral","deep","fair","olive"])
    st.markdown("---")
    style       = st.selectbox("Style Vibe",         ["casual","streetwear","minimal","formal","sporty","party","vintage","elegant"])
    comfort     = st.selectbox("Comfort Preference", ["loose","regular","tight"], index=1)
    color_pref  = st.selectbox("Color Palette",      ["any","dark","light","neutral","bright"])
    n_outfits   = st.slider("Number of Outfits", 3, 8, 5)
    st.markdown("---")

    # Upload
    st.markdown('<div style="color:#5C5448;font-size:0.62rem;letter-spacing:0.12em;text-transform:uppercase;margin-bottom:0.4rem">📸 Upload Your Item</div>', unsafe_allow_html=True)
    uploaded_file = st.file_uploader("Drop a clothing photo", type=["jpg","jpeg","png","webp"], label_visibility="collapsed")
    if uploaded_file:
        cat   = detect_category_from_filename(uploaded_file.name)
        color = detect_dominant_color_from_name(uploaded_file.name)
        st.session_state.upload_category = cat
        st.session_state.upload_color    = color
        st.markdown(f'<div class="det-badge">✓ Detected: <b>{cat.replace("_"," ").title()}</b></div>', unsafe_allow_html=True)
        st.image(uploaded_file, use_column_width=True)

    st.markdown("---")
    generate_btn = st.button("✦ Generate My Outfits", use_container_width=True)
    st.markdown("""
    <div style="padding:1rem 0 0;font-size:0.67rem;color:#3E3830;line-height:2.1">
      🧠 Rule-Based Intelligence<br>
      📊 ML Scoring Pipeline<br>
      🔍 Explainable AI (XAI)<br>
      🗂️ 50K+ Item Dataset<br>
      🕸️ Graph-Ready Architecture
    </div>""", unsafe_allow_html=True)


# ── Hero ───────────────────────────────────────────────────────────────────────
st.markdown("""
<div class="xf-hero">
  <div class="xf-wordmark">Explainable AI · Personal Stylist</div>
  <h1>Dress <em>smarter</em>,<br>not just better.</h1>
  <p>AI-curated outfits with full reasoning · Western &amp; Ethnic · 50K+ items · Buy The Look</p>
</div>
""", unsafe_allow_html=True)


# ── Card renderer ──────────────────────────────────────────────────────────────
def safe_color(item) -> str:
    return item.color if item else "default"


def render_card(outfit: Outfit, rank: int, vibe: tuple, profile: UserProfile) -> str:
    score = outfit.score
    grade = score_to_grade(score)
    vibe_text, vibe_emoji = vibe

    grade_colors = {"S":"#B8860B","A":"#8B6F47","B":"#5B8A6F","C":"#4A6BA3","D":"#C0574A"}
    gc = grade_colors.get(grade, "#888")

    # SVG illustration
    svg = generate_outfit_svg(
        top_color    = safe_color(outfit.top),
        bottom_color = safe_color(outfit.bottom),
        shoe_color   = safe_color(outfit.shoes),
        outer_color  = safe_color(outfit.outerwear),
        outfit_type  = outfit.outfit_type,
        style        = outfit.style_label.lower(),
    )
    svg_b64 = base64.b64encode(svg.encode()).decode()

    html = f"""<div class="outfit-card">
  <div class="card-illus">
    <img src="data:image/svg+xml;base64,{svg_b64}" alt="outfit illustration"/>
    <div class="grade-pill" style="background:{gc}">{grade}</div>
    <div class="vibe-tag">{vibe_emoji} {vibe_text}</div>
    <div class="rank-tag">#{rank}</div>
  </div>
  <div class="card-body">
    <div class="card-title">{outfit.style_label} Look</div>
    <div class="card-sub">{outfit.outfit_type.replace("_"," ").title()} &middot; {score}/100</div>
    <div class="score-track"><div class="score-fill" style="width:{score}%"></div></div>
    <div class="items-sec">"""

    slots = [("Top",outfit.top),("Bottom",outfit.bottom),
             ("Outerwear",outfit.outerwear),("Shoes",outfit.shoes),("Accessories",outfit.accessories)]
    for slot_name, item in slots:
        if item is None:
            html += f'<div class="item-row"><div class="item-slot">{slot_name}</div><span style="color:#ccc;font-size:0.73rem">—</span></div>'
        else:
            emoji   = get_item_emoji(item.item_name)
            name    = format_item_name(item.item_name)
            chex    = get_color_hex(item.color)
            cname   = item.color.replace("_"," ").title()
            fit     = item.fit.replace("_"," ")
            html += f"""<div class="item-row">
              <div class="item-slot">{slot_name}</div>
              <div class="item-emoji">{emoji}</div>
              <div class="item-name">{name} <span class="item-fit">&middot; {fit}</span></div>
              <div class="cswatch" style="background:{chex}" title="{cname}"></div>
              <div class="cname">{cname}</div>
            </div>"""

    html += "</div>"  # end items-sec

    # XAI
    if outfit.explanations:
        html += '<div class="xai-box"><div class="xai-lbl">🔍 Why this works</div>'
        for exp in outfit.explanations[:5]:
            clean = exp.split("—")[-1].strip() if "—" in exp else exp
            clean = (clean[:88]+"…") if len(clean) > 88 else clean
            html += f'<div class="xai-pt">{clean}</div>'
        html += "</div>"

    # Hairstyle
    hairs = get_hairstyle_suggestions(profile.style, profile.body_type)
    html += '<div class="hair-row"><div class="hair-lbl">💇 Hair vibes</div>'
    for h in hairs[:3]:
        html += f'<div class="hair-chip">{h}</div>'
    html += "</div>"

    # Buy the look
    primary = outfit.top or outfit.bottom
    if primary:
        html += f'<div class="shop-lbl">🛍️ Buy The Look</div>'
        html += get_shop_links(primary.item_name, primary.color)

    html += "</div></div>"  # end card-body, outfit-card
    return html


# ── Generate ───────────────────────────────────────────────────────────────────
if generate_btn:
    profile = UserProfile(
        weather=weather, occasion=occasion, outfit_type=outfit_type,
        body_type=body_type, skin_tone=skin_tone, style=style,
        comfort=comfort, color_preference=color_pref,
    )
    with st.spinner("✦ Curating your personalised outfits…"):
        try:
            engine  = load_engine()
            outfits = engine.recommend(profile, n_outfits=n_outfits)
            st.session_state.outfits = outfits
            st.session_state.profile = profile
        except Exception as e:
            st.error(f"Engine error: {e}")
            st.exception(e)


# ── Display ────────────────────────────────────────────────────────────────────
if st.session_state.outfits:
    profile = st.session_state.profile
    outfits = st.session_state.outfits
    avg_score = sum(o.score for o in outfits) / len(outfits)
    best = max(outfits, key=lambda o: o.score)

    # Profile strip
    icons = ["🌤","📅","👗","🧍","🎨","💫","🤗"]
    vals  = [profile.weather, profile.occasion, profile.outfit_type,
             profile.body_type, profile.skin_tone, profile.style, profile.comfort]
    tags  = "".join([f'<span class="ptag">{i} {v.replace("_"," ").title()}</span>' for i,v in zip(icons,vals)])
    st.markdown(f'<div class="profile-strip"><span class="plabel">Profile</span>{tags}</div>', unsafe_allow_html=True)

    # Stats
    vibe_text, vibe_emoji = get_outfit_vibe(profile.style, profile.weather)
    c1,c2,c3,c4 = st.columns(4)
    with c1: st.metric("Outfits", len(outfits))
    with c2: st.metric("Avg Score", f"{avg_score:.0f}/100")
    with c3: st.metric("Top Score", f"{best.score:.0f}/100")
    with c4: st.metric("Vibe", f"{vibe_emoji} {vibe_text[:16]}…" if len(vibe_text)>16 else f"{vibe_emoji} {vibe_text}")
    st.markdown("---")

    tab1, tab2, tab3 = st.tabs(["✦ Gallery", "🏆 Ranked", "📊 Insights"])

    with tab1:
        pairs = [outfits[i:i+2] for i in range(0,len(outfits),2)]
        for pair in pairs:
            cols = st.columns(len(pair))
            for col, outfit in zip(cols, pair):
                rank = outfits.index(outfit) + 1
                with col:
                    st.markdown(render_card(outfit, rank, get_outfit_vibe(profile.style, profile.weather), profile),
                                unsafe_allow_html=True)

    with tab2:
        medals = ["🥇","🥈","🥉"] + [f"#{i}" for i in range(4,20)]
        for rank, outfit in enumerate(sorted(outfits, key=lambda o: -o.score), 1):
            cols = st.columns([0.06, 0.94])
            with cols[0]:
                st.markdown(f"<div style='font-size:1.5rem;text-align:center;margin-top:1.4rem'>{medals[rank-1]}</div>", unsafe_allow_html=True)
            with cols[1]:
                st.markdown(render_card(outfit, rank, get_outfit_vibe(profile.style, profile.weather), profile),
                            unsafe_allow_html=True)

    with tab3:
        st.markdown("### 📊 Style Intelligence Report")
        col_a, col_b = st.columns(2)

        with col_a:
            st.markdown("**Color Distribution**")
            color_counts: dict = {}
            for o in outfits:
                for item in [o.top, o.bottom, o.outerwear, o.shoes, o.accessories]:
                    if item:
                        c = item.color.replace("_"," ").title()
                        color_counts[c] = color_counts.get(c, 0) + 1
            for color, cnt in sorted(color_counts.items(), key=lambda x:-x[1])[:8]:
                chex = get_color_hex(color.lower().replace(" ","_"))
                st.markdown(
                    f'<div style="display:flex;align-items:center;gap:0.6rem;margin:0.3rem 0">'
                    f'<div style="width:11px;height:11px;border-radius:3px;background:{chex};border:1px solid #ddd;flex-shrink:0"></div>'
                    f'<span style="font-size:0.8rem;flex:1">{color}</span>'
                    f'<div style="width:80px;height:5px;background:#EEE;border-radius:3px">'
                    f'<div style="height:5px;width:{cnt*20}%;background:{chex};border-radius:3px;max-width:100%"></div></div>'
                    f'<span style="font-size:0.7rem;color:#888;width:16px;text-align:right">{cnt}</span></div>',
                    unsafe_allow_html=True)

        with col_b:
            st.markdown("**Outfit Score Breakdown**")
            grade_colors = {"S":"#B8860B","A":"#8B6F47","B":"#5B8A6F","C":"#4A6BA3","D":"#C0574A"}
            for o in sorted(outfits, key=lambda x:-x.score):
                g = score_to_grade(o.score)
                gc = grade_colors.get(g,"#888")
                st.markdown(
                    f'<div style="display:flex;align-items:center;gap:0.6rem;margin:0.4rem 0">'
                    f'<span style="font-size:0.73rem;font-weight:700;color:{gc};width:18px">{g}</span>'
                    f'<div style="flex:1;height:7px;background:#EEE;border-radius:4px">'
                    f'<div style="height:7px;width:{o.score}%;background:{gc};border-radius:4px;opacity:0.8"></div></div>'
                    f'<span style="font-size:0.72rem;color:#888;width:48px;text-align:right">{o.score:.0f}/100</span></div>',
                    unsafe_allow_html=True)

        st.markdown("---")
        vt, ve = get_outfit_vibe(profile.style, profile.weather)
        st.markdown(f"**Today's Vibe:** {ve} *{vt}*")
        hairs = get_hairstyle_suggestions(profile.style, profile.body_type)
        st.markdown(f"**Recommended Hairstyles:** {' · '.join(hairs)}")

        st.markdown("**Items Distribution by Category**")
        cat_counts: dict = {}
        for o in outfits:
            for slot, item in [("Top",o.top),("Bottom",o.bottom),("Outerwear",o.outerwear),("Shoes",o.shoes),("Accessories",o.accessories)]:
                if item:
                    cat_counts[slot] = cat_counts.get(slot,0) + 1
        for cat, cnt in cat_counts.items():
            st.markdown(
                f'<div style="display:flex;align-items:center;gap:0.6rem;margin:0.3rem 0">'
                f'<span style="font-size:0.78rem;width:80px">{cat}</span>'
                f'<div style="flex:1;height:6px;background:#EEE;border-radius:3px">'
                f'<div style="height:6px;width:{cnt/max(cat_counts.values())*100:.0f}%;background:var(--accent);border-radius:3px;opacity:0.7"></div></div>'
                f'<span style="font-size:0.72rem;color:#888;width:24px">{cnt}</span></div>',
                unsafe_allow_html=True)


# ── Empty state ────────────────────────────────────────────────────────────────
else:
    st.markdown("""
    <div class="empty-wrap">
      <div class="e-icon">✦</div>
      <h2>Your Style, Explained</h2>
      <p>Set your preferences in the sidebar and let our AI curate personalised outfit looks — with full explainability, colour harmony, and one-click shopping.</p>
    </div>
    <div class="feat-grid">
      <div class="feat-card"><div class="feat-icon">🧠</div><div class="feat-title">Fashion Intelligence</div><div class="feat-desc">Body-type rules, colour harmony, season &amp; occasion filtering built right in.</div></div>
      <div class="feat-card"><div class="feat-icon">🔍</div><div class="feat-title">Explainable AI</div><div class="feat-desc">Every outfit tells you <em>why</em> it was chosen. No black boxes. Full transparency.</div></div>
      <div class="feat-card"><div class="feat-icon">🛍️</div><div class="feat-title">Buy The Look</div><div class="feat-desc">Shop each recommendation on Myntra, Amazon, Nykaa &amp; Savana instantly.</div></div>
      <div class="feat-card"><div class="feat-icon">📸</div><div class="feat-title">Upload Your Item</div><div class="feat-desc">Upload a clothing piece you own — we'll build a complete outfit around it.</div></div>
      <div class="feat-card"><div class="feat-icon">💇</div><div class="feat-title">Hairstyle Pairing</div><div class="feat-desc">Every look comes with curated hairstyle suggestions to complete the vibe.</div></div>
      <div class="feat-card"><div class="feat-icon">🗂️</div><div class="feat-title">50K+ Items</div><div class="feat-desc">Spanning Western &amp; Indian fashion with intelligent rule-biased distributions.</div></div>
    </div>
    """, unsafe_allow_html=True)
